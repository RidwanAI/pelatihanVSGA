<form action="TugasMuhammadRidwan_layerKedua.php" method="post">
	<p>============== Menu ==============</p>
	<p>Bangun Ruang yang Tersedia : </p>
	<ol>
		<li>Luas Segitiga</li>
		<li>Luas Persegi</li>
		<li>Luas Lingkaran</li>
	</ol>
	Pilih Bangun Ruang yang Tersedia di Menu : <br>
	<select name="luasBangdat">
		<option disabled selected>Pilih Menu :</option>
		<option value="Luas Segitiga">Luas Segitiga</option>
		<option value="Luas Persegi">Luas Persegi</option>
		<option value="Luas Lingkaran">Luas Lingkaran</option>
	</select>
	<br/><br/>
	<input type="submit" value="pilih" name="pilihanLuas"/>
	<input type="reset" value="Batal"/>
	<p>==================================</p>
</form>
