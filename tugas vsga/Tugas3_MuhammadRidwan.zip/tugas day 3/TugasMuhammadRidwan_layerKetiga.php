<?php

    if(isset($_POST['luasSegitiga'])){
        if(!empty($_POST['luasSegitiga'])) {
            $alas = $_POST["alas"];
            $tinggi = $_POST["tinggi"];
            $alasSegitiga = $alas;
            $tinggiSegitiga = $tinggi;
            $HluasSegitiga = 0.5 * $alasSegitiga * $tinggiSegitiga;
            echo '<b><u>Hasil Luas Segitiga:</u></b> <br><br>';
            echo 'Alas Segitiga : '.$alasSegitiga.' cm<br>';
            echo 'Tinggi Segitiga : '.$tinggiSegitiga.' cm<br><br>';
            echo '<b>Luas Segitiganya Adalah '.$HluasSegitiga.' cm</b>';
        }
    }
    elseif(isset($_POST['luasPersegi'])){
        if(!empty($_POST['luasPersegi'])) {
            $sisi = $_POST["sisi"];
            $sisiPersegi = $sisi;
            $HluasPersegi = pow($sisiPersegi, 2);
            echo '<b><u>Hasil Luas Persegi:</u></b> <br><br>';
            echo 'Sisi Persegi: '.$sisiPersegi.' cm<br><br>';
            echo '<b>Luas Segitiganya Adalah '.$HluasPersegi.' cm</b>';
        }
    }
    elseif(isset($_POST['luasLingkaran'])){
        if(!empty($_POST['luasLingkaran'])) {
            $jari = $_POST["jari"];
            $jariLingkaran = $jari;
            $HluasLingkaran = pi() * pow($jariLingkaran, 2);
            echo '<b><u>Hasil Luas Lingkaran:</u></b> <br><br>';
            echo 'Jari-Jari Lingkaran: '.$jariLingkaran.' cm<br><br>';
            echo '<b>Luas Segitiganya Adalah '.$HluasLingkaran.' cm</b>';
        }
    }

    $file = "tugasvsga.json";

    $tugas = file_get_contents($file);

    $data = json_decode($tugas, true);

    if ($segitiga = $_POST['luasSegitiga'] = true) {
        $alasSegitiga = $_POST["alas"];
        $tinggiSegitiga = $_POST["tinggi"];
        $LA = $alasSegitiga;
        $LT = $tinggiSegitiga;
        $data[] = array(
            'Pilihan Perhitungan Luas Bangun Datar' => "Luas Segitiga",
            'Alas' => "$LA",
            'Tinggi' => "$LT",
        );
    }; 
    if ($persegi = $_POST['luasPersegi'] = true) {
        $sisiPersegi = $_POST["sisi"];
        $SI = $sisiPersegi;
        $data[] = array(
            'Pilihan Perhitungan Luas Bangun Datar' => "Luas Persegi",
            'Sisi Persegi' => "$SI",
        );
    }; 
    if ($lingkaran = $_POST['luasLingkaran'] = true) {
        $jariLingkaran = $_POST["jari"];
        $JR = $jariLingkaran;
        $data[] = array(
            'Pilihan Perhitungan Luas Bangun Datar' => "Luas Lingkaran",
            'Phi' => "3.14",
            'Jari-jari Lingkaran' => "$JR",
        );
    };

    $tupdat = json_encode($data, JSON_PRETTY_PRINT);

    file_put_contents($file, $tupdat);

?>

<form action="TugasMuhammadRidwan_layerUtama.php" method="post">
    <br>
    <input type="submit" name="kembali" value="kembali">
</form>